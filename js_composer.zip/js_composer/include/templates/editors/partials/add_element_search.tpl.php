<?php
/**
 * Add element search template.
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

?>
<div class="vc_ui-panel-header-actions">
	<div class="wpb-search-input">
		<input type="text" id="vc_elements_name_filter" class="wpb-form-input">
	</div>
</div>
